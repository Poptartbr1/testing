import datetime

def write_transaction(day, amount, type, desc):
    print("DAY: {0} AMOUNT: {1} TYPE: {2} DESCRIPTION: {3}".format(day,amount,type,desc))

def operation_add(account, *args):
    if(len(args) != 3):
        raise SyntaxError
    amount = int(args[0])
    if(args[1] != 'in' and args[1] != 'out'):
        raise TypeError
    tran_type = args[1]
    desc = args[2]
    day = datetime.datetime.today().day
    account.append({"day": day, "amount": amount, "type": tran_type, "desc": desc})

def operation_insert(account, *args):
    if (len(args) != 4):
        raise SyntaxError
    day = int(args[0])
    if(day < 0 or day > 30):
        raise Exception("day should be an integer between 0-30")
    amount = int(args[1])
    if (args[2] != 'in' and args[2] != 'out'):
        raise TypeError
    tran_type = args[2]
    desc = args[3]
    account.append({"day": day, "amount": amount, "type": tran_type, "desc": desc})

def list_all(account):
    new_list = sorted(account, key=lambda k: k["day"])
    for e in new_list:
        write_transaction(e["day"], e["amount"], e["type"],e["desc"])

def list_type(account, type):
    new_list = sorted(account, key=lambda k: k["day"])
    for e in new_list:
        if(e["type"] == type):
            write_transaction(e["day"], e["amount"], e["type"], e["desc"])

def list_balance(account, day):
    sum = 0
    new_list = sorted(account, key=lambda k: k["day"])
    for e in new_list:
        if(e["day"] > day):
            break
        if(e["type"] == "in"):
            sum+=e["amount"]
        if(e["type"] == "out"):
            sum-=e["amount"]
    print("BALANCE OF YOUR ACCOUNT IS: {0} RON".format(sum))

def list_property(account, symbol, value):
    new_list = sorted(account, key=lambda k: k["day"])
    if symbol == "=":
        for e in new_list:
            if(e["amount"] == value):
                write_transaction(e["day"], e["amount"], e["type"], e["desc"])
    if symbol == "<":
        for e in new_list:
            if (e["amount"] < value):
                write_transaction(e["day"], e["amount"], e["type"], e["desc"])
    if symbol == ">":
        for e in new_list:
            if(e["amount"] > value):
                write_transaction(e["day"], e["amount"], e["type"], e["desc"])

def operation_list(account, *args):
    if len(account) == 0:
        raise Exception("List is empty")
    args_size = len(args)
    if args_size == 0: #case print all
        list_all(account)
    elif args_size == 1: #print only transactions with type in or out
        if (args[0] != 'in' and args[0] != 'out'):
            raise TypeError
        list_type(account, args[0])
    elif args_size == 2:
        #there are 2 cases, either printing transactions with a condition on amount, or computing balance on a day
        #we have to check what case we are on, we will do it by checking the first parameter
        symbols = ["<","=",">"]
        #case 1
        if args[0] in symbols:
            symbol = args[0]
            value = int(args[1])
            list_property(account, symbol, value)
        #case 2
        elif args[0] == "balance":
            day = int(args[1])
            list_balance(account,day)
        else:
            raise SyntaxError
    else:
        raise SyntaxError

def remove_single(account,day):
    account[:] = [d for d in account if d.get("day") != day]

def remove_type(account,type):
    account[:] = [d for d in account if d.get("type") != type]

def remove_range(account,start,end):
    for i in range(start,end+1):
        account[:] = [d for d in account if d.get("day") != i]

def operation_remove(account, *args):
    args_size = len(args)
    if args_size == 1:
        if args[0].isdigit():
            day = int(args[0])
            if (day < 0 or day > 30):
                raise Exception("day should be an integer between 0-30")
            remove_single(account,day)
        else:
            if(args[0] != "in" and args[0] != "out"):
                raise TypeError
            remove_type(account,args[0])
    elif args_size == 3:
        start_day = int(args[0])
        end_day = int(args[2])
        if start_day > end_day:
            raise Exception("starting day should be lower or equal than end day")
        if args[1] != "to":
            raise SyntaxError
        if (start_day < 0 or start_day > 30 or end_day < 0 or end_day > 30):
            raise Exception("day should be an integer between 0-30")
        remove_range(account,start_day,end_day)
    else:
        raise SyntaxError

def replace(account, day, type, desc, value):
    new_list = sorted(account, key=lambda k: k["day"])
    for e in new_list:
        if(e["day"] == day and e["type"] == type and e["desc"] == desc):
            e["amount"] = value
        if(e["day"] > day):
            break
    return new_list

def operation_replace(account, *args):
    args_size = len(args)
    if args_size != 5:
        raise SyntaxError
    day = int(args[0])
    type = args[1]
    if(type != "in" and type != "out"):
        raise TypeError
    desc = args[2]
    if args[3] != "with":
        raise SyntaxError
    value = int(args[4])
    account[:] = replace(account, day, type, desc, value)

def sum_type(account, type):
    sum = 0
    for e in account:
        if e["type"] == type:
            sum += e["amount"]
    print("TOTAL SUM OF", type,"TRANSACTIONS IS", sum)

def sum_day_type(account, day, type):
    sum = 0
    for e in account:
        if(e["day"] == day and e["type"]==type):
            sum+= e["amount"]
    print("TOTAL SUM OF", type, "TRANSACTIONS IN DAY", day, "IS", sum)

def operation_sum(account, *args):
    args_size = len(args)
    if args_size == 1:
        type = args[0]
        if(type != "in" and type != "out"):
            raise TypeError
        sum_type(account, type)
    elif args_size == 2:
        type = args[0]
        if (type != "in" and type != "out"):
            raise TypeError
        day = int(args[1])
        if(day<0 or day>30):
            raise Exception("day should be an integer between 0-30")
        sum_day_type(account,day,type)
    else:
        raise SyntaxError