from src.ro.ubb.bankaccount.operations.operations import operation_add, operation_insert, operation_list, operation_remove, operation_replace, operation_sum

def read_cmd():
    line = input("cmd: ")
    pos = line.find(' ')
    if pos == -1:
        return line, []
    cmd = line[:pos]
    args = line[pos + 1:]
    args = [s.strip() for s in args.split(' ')]
    return cmd,args

def print_commands(commands):
    print(*list(commands.keys()), "exit")

def run_cmd():
    account = [{"day": 0, "amount": 150, "type": "in", "desc": "test"},
               {"day": 0, "amount": 141, "type": "in", "desc": "test"},
               {"day": 0, "amount": 131, "type": "out", "desc": "test"},
               {"day": 2, "amount": 150, "type": "in", "desc": "test"}]
    commands = {"add": operation_add,
                "insert": operation_insert,
                "list": operation_list,
                "replace": operation_replace,
                "remove": operation_remove,
                "sum": operation_sum}
    commands_syntax = {"add": "add <amount> <type> <description>",
                       "insert": "insert <day> <amount> <type> <description>",
                       "list": "list | list [<|=|>] <value> | list balance <day>",
                       "remove": "remove <day> | remove <type> | remove <start_day> to <end_day>",
                       "replace": "replace <day> <type> <description> with <value>",
                       "sum": "sum <type> | sum <type> <day>"}

    print_commands(commands)
    while True:
        cmd, args = read_cmd()
        if cmd == "exit":
            break
        try:
            commands[cmd](account, *args)
        except KeyError:
            print("option not exist")
        except ValueError:
            print("Invalid parameter(s) type")
        except SyntaxError:
            print("Syntax: ", commands_syntax[cmd])
        except TypeError:
            print("Invalid type of transaction")
        except Exception as error_msg:
            print(error_msg)
